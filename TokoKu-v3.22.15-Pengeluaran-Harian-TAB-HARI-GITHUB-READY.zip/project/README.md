# TokoKu v3.22.15 - Pengeluaran Harian

Versi ini memakai source TokoKu v3.22.9 Printer Bluetooth sebagai dasar dan menambahkan/menjaga fitur Pengeluaran Harian.

## Fitur Pengeluaran Harian
- Tab pengeluaran berdasarkan tanggal.
- Pilih bulan.
- Total pengeluaran bulanan.
- Jumlah item pengeluaran.
- Rincian item per hari.
- Tambah beberapa item dalam satu tanggal.
- Kategori, jumlah, satuan, harga satuan, dan catatan.
- Hapus item pengeluaran.
- Laporan bulanan menghitung Penjualan - Pengeluaran.
- Laporan Laba & Rugi menghitung laba bersih setelah pengeluaran.

## Build APK
GitHub Actions: `.github/workflows/build-v3.22.15-pengeluaran-harian.yml`

Workflow sengaja membuat **DEBUG APK tanpa proses keystore/signing manual**, supaya tidak terkena kegagalan `Sign APK` yang terjadi pada workflow sebelumnya.

Hasil artifact:
`TokoKu-v3.22.15-Pengeluaran-Harian.apk`

Catatan: APK debug memiliki tanda tangan debug. Jika Android menolak instalasi karena ada versi TokoKu lama dengan signature berbeda, uninstall versi lama terlebih dahulu atau gunakan data backup/restore yang kompatibel.
